package com.example.programminglanguages_project

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
